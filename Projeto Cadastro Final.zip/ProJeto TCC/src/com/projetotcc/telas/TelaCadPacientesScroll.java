/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.projetotcc.telas;

import java.sql.*;
import com.projetotcc.mod.ModConexao;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author sulli
 */
public class TelaCadPacientesScroll extends javax.swing.JFrame {

    Connection conexao = null;

    PreparedStatement pst = null;

    ResultSet rs = null;

    /**
     * Creates new form TelaCadPacientesScroll
     */
    public TelaCadPacientesScroll() {
        initComponents();
        conexao = ModConexao.conectar();
    }

    private void criar() {
        String sql = "insert into tbpacientes ( nome, idade,data_de_nascimento, cpf, sexo,  estado_civil, profissao, endereco, telefone, celular,peso, altura, diagnostico_clinico, diagnostico_fisioterapeutico, queixa_principal,historia_doenca_atual, historia_doenca_pregressa,  medicamentos, comorbidades, atividades_fisicas, quais_atividades, frequencia, duracao, pa, fc, fr, inspecao, goniometria, testes_especificos, testes_complementares, dor, objetivos, email, palpacao)  values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        try {

            pst = conexao.prepareStatement(sql);

            pst.setString(1, txtCadNome.getText());
            pst.setString(2, txtCadIdade.getText());
            pst.setString(3, txtCadData.getText());
            pst.setString(4, txtCadCPF.getText());
            pst.setString(5, txtCadSexo.getText());
            pst.setString(6, txtCadEstCivil.getText());
            pst.setString(7, txtCadProf.getText());
            pst.setString(8, txtCadEnd.getText());
            pst.setString(9, txtCadTel.getText());
            pst.setString(10, txtCadCel.getText());
            pst.setString(11, txtCadPeso.getText());
            pst.setString(12, txtCadAltura.getText());
            pst.setString(13, txtCadDiagClin.getText());
            pst.setString(14, txtCadDiagFisio.getText());
            pst.setString(15, txtCadQPrinc.getText());
            pst.setString(16, txtCadHDA.getText());
            pst.setString(17, txtCadHDP.getText());
            pst.setString(18, txtCadMedi.getText());
            pst.setString(19, txtCadComorb.getText());
            pst.setString(20, txtCadAFisicas.getText());
            pst.setString(21, txtCadQuais.getText());
            pst.setString(22, txtCadFreq.getText());
            pst.setString(23, txtCadDuracao.getText());
            pst.setString(24, txtCadPA.getText());
            pst.setString(25, txtCadFC.getText());
            pst.setString(26, txtCadFR.getText());
            pst.setString(27, txtCadInsp.getText());
            pst.setString(28, txtCadGonio.getText());
            pst.setString(29, txtCadTestEspec.getText());
            pst.setString(30, txtCadTestComp.getText());
            pst.setString(31, txtCadDor.getText());
            pst.setString(32, txtCadObj.getText());
            pst.setString(33, txtCadEmail.getText());
            pst.setString(34, txtCadPalp.getText());

            if ((txtCadNome.getText().isEmpty()) || (txtCadSexo.getText().isEmpty()) || (txtCadCel.getText().isEmpty())) {
                JOptionPane.showMessageDialog(null, "Por favor preencha todos os campos obrigatórios");
            } else {
                int verificar = pst.executeUpdate();

                if (verificar > 0) {
                    JOptionPane.showMessageDialog(null, "Paciente Cadastrado com sucesso!!");
                    limpartudo();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    private void pesquisa() {
        String sql = "select idpac as ID, nome as Nome, idade as Idade, data_de_nascimento as DtNasc, cpf as CPF, sexo as Sexo, estado_civil as EstadoCivil, profissao as Profissao, endereco as Endereco, telefone as Telefone, celular as Celular, peso as Peso, altura as Altura, diagnostico_clinico as DiagnósticoClínico, diagnostico_fisioterapeutico as DiagnósticoFisioterapêutico, queixa_principal as QueixaPrincipal, historia_doenca_atual as HDA, historia_doenca_pregressa as HDP, medicamentos as Medicamentos,comorbidades as Comorbidades,atividades_fisicas as AtividadesFísicas,quais_atividades as QuaisAtividades,frequencia as Frequência,duracao as Duração,pa as PA,fc as FC,fr as FR,inspecao as Inspeção,goniometria as Goniometria,testes_especificos as TestesEspecíficos,testes_complementares as TestesComplementares,dor as Dor,objetivos as Objetivos,email as Email,palpacao as Palpação from tbpacientes where nome like ?";
        try {

            pst = conexao.prepareStatement(sql);

            pst.setString(1, txtPesquisa.getText() + "%");

            rs = pst.executeQuery();

            tblPacientes.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void setcampos() {

        btnCadCreate.setEnabled(false);
        int set = tblPacientes.getSelectedRow();
        txtCadID.setText(tblPacientes.getModel().getValueAt(set, 0).toString());
        txtCadNome.setText(tblPacientes.getModel().getValueAt(set, 1).toString());
        txtCadIdade.setText(tblPacientes.getModel().getValueAt(set, 2).toString());
        txtCadData.setText(tblPacientes.getModel().getValueAt(set, 3).toString());
        txtCadCPF.setText(tblPacientes.getModel().getValueAt(set, 4).toString());
        txtCadSexo.setText(tblPacientes.getModel().getValueAt(set, 5).toString());
        txtCadEstCivil.setText(tblPacientes.getModel().getValueAt(set, 6).toString());
        txtCadProf.setText(tblPacientes.getModel().getValueAt(set, 7).toString());
        txtCadEnd.setText(tblPacientes.getModel().getValueAt(set, 8).toString());
        txtCadTel.setText(tblPacientes.getModel().getValueAt(set, 9).toString());
        txtCadCel.setText(tblPacientes.getModel().getValueAt(set, 10).toString());
        txtCadPeso.setText(tblPacientes.getModel().getValueAt(set, 11).toString());
        txtCadAltura.setText(tblPacientes.getModel().getValueAt(set, 12).toString());
        txtCadDiagClin.setText(tblPacientes.getModel().getValueAt(set, 13).toString());
        txtCadDiagFisio.setText(tblPacientes.getModel().getValueAt(set, 14).toString());
        txtCadQPrinc.setText(tblPacientes.getModel().getValueAt(set, 15).toString());
        txtCadHDA.setText(tblPacientes.getModel().getValueAt(set, 16).toString());
        txtCadHDP.setText(tblPacientes.getModel().getValueAt(set, 17).toString());
        txtCadMedi.setText(tblPacientes.getModel().getValueAt(set, 18).toString());
        txtCadComorb.setText(tblPacientes.getModel().getValueAt(set, 19).toString());
        txtCadAFisicas.setText(tblPacientes.getModel().getValueAt(set, 20).toString());
        txtCadQuais.setText(tblPacientes.getModel().getValueAt(set, 21).toString());
        txtCadFreq.setText(tblPacientes.getModel().getValueAt(set, 23).toString());
        txtCadDuracao.setText(tblPacientes.getModel().getValueAt(set, 24).toString());
        txtCadPA.setText(tblPacientes.getModel().getValueAt(set, 25).toString());
        txtCadFC.setText(tblPacientes.getModel().getValueAt(set, 26).toString());
        txtCadFR.setText(tblPacientes.getModel().getValueAt(set, 27).toString());
        txtCadInsp.setText(tblPacientes.getModel().getValueAt(set, 28).toString());
        txtCadGonio.setText(tblPacientes.getModel().getValueAt(set, 29).toString());
        txtCadTestEspec.setText(tblPacientes.getModel().getValueAt(set, 30).toString());
        txtCadTestComp.setText(tblPacientes.getModel().getValueAt(set, 31).toString());
        txtCadDor.setText(tblPacientes.getModel().getValueAt(set, 32).toString());
        txtCadObj.setText(tblPacientes.getModel().getValueAt(set, 33).toString());
        txtCadEmail.setText(tblPacientes.getModel().getValueAt(set, 34).toString());
        txtCadPalp.setText(tblPacientes.getModel().getValueAt(set, 35).toString());

    }

    private void editar() {

        String sql = "update tbpacientes set nome=?, idade=?,data_de_nascimento=?, cpf=?, sexo=?,  estado_civil=?, profissao=?, endereco=?, telefone=?, celular=?,peso=?, altura=?, diagnostico_clinico=?, diagnostico_fisioterapeutico=?, queixa_principal=?,historia_doenca_atual=?, historia_doenca_pregressa=?,  medicamentos=?, comorbidades=?, atividades_fisicas=?, quais_atividades=?, frequencia=?, duracao=?, pa=?, fc=?, fr=?, inspecao=?, goniometria=?, testes_especificos=?, testes_complementares=?, dor=?, objetivos=?, email=?, palpacao=? where idpac=?";
        try {
            pst = conexao.prepareStatement(sql);

            pst.setString(1, txtCadNome.getText());
            pst.setString(2, txtCadIdade.getText());
            pst.setString(3, txtCadData.getText());
            pst.setString(4, txtCadCPF.getText());
            pst.setString(5, txtCadSexo.getText());
            pst.setString(6, txtCadEstCivil.getText());
            pst.setString(7, txtCadProf.getText());
            pst.setString(8, txtCadEnd.getText());
            pst.setString(9, txtCadTel.getText());
            pst.setString(10, txtCadCel.getText());
            pst.setString(11, txtCadPeso.getText());
            pst.setString(12, txtCadAltura.getText());
            pst.setString(13, txtCadDiagClin.getText());
            pst.setString(14, txtCadDiagFisio.getText());
            pst.setString(15, txtCadQPrinc.getText());
            pst.setString(16, txtCadHDA.getText());
            pst.setString(17, txtCadHDP.getText());
            pst.setString(18, txtCadMedi.getText());
            pst.setString(19, txtCadComorb.getText());
            pst.setString(20, txtCadAFisicas.getText());
            pst.setString(21, txtCadQuais.getText());
            pst.setString(22, txtCadFreq.getText());
            pst.setString(23, txtCadDuracao.getText());
            pst.setString(24, txtCadPA.getText());
            pst.setString(25, txtCadFC.getText());
            pst.setString(26, txtCadFR.getText());
            pst.setString(27, txtCadInsp.getText());
            pst.setString(28, txtCadGonio.getText());
            pst.setString(29, txtCadTestEspec.getText());
            pst.setString(30, txtCadTestComp.getText());
            pst.setString(31, txtCadDor.getText());
            pst.setString(32, txtCadObj.getText());
            pst.setString(33, txtCadEmail.getText());
            pst.setString(34, txtCadPalp.getText());
            pst.setString(35, txtCadID.getText());

            if ((txtCadNome.getText().isEmpty()) || (txtCadSexo.getText().isEmpty()) || (txtCadCel.getText().isEmpty())) {
                JOptionPane.showMessageDialog(null, "Por favor preencha todos os campos obrigatórios");
            } else {
                int verificar = pst.executeUpdate();

                if (verificar > 0) {
                    JOptionPane.showMessageDialog(null, "Cadastrado editado com sucesso!!");
                    limpartudo();
                    btnCadCreate.setEnabled(true);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    private void deletar() {

        int deletado = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja deletar este Paciente?", "Atenção", JOptionPane.YES_NO_OPTION);
        if (deletado == JOptionPane.YES_OPTION) {

            String sql = "delete from tbpacientes where idpac=?";
            try {
                pst = conexao.prepareStatement(sql);

                pst.setString(1, txtCadID.getText());
                int confirmacao = pst.executeUpdate();

                if (confirmacao > 0) {
                    JOptionPane.showMessageDialog(null, "Paciente deletado com sucesso");

                    limpartudo();

                    btnCadCreate.setEnabled(true);
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }

        }
    }

    public void limpartudo() {
        txtCadID.setText(null);
        txtCadNome.setText(null);
        txtCadIdade.setText(null);
        txtCadData.setText(null);
        txtCadCPF.setText(null);
        txtCadSexo.setText(null);
        txtCadEstCivil.setText(null);
        txtCadProf.setText(null);
        txtCadEnd.setText(null);
        txtCadTel.setText(null);
        txtCadCel.setText(null);
        txtCadPeso.setText(null);
        txtCadAltura.setText(null);
        txtCadDiagClin.setText(null);
        txtCadDiagFisio.setText(null);
        txtCadQPrinc.setText(null);
        txtCadHDA.setText(null);
        txtCadHDP.setText(null);
        txtCadMedi.setText(null);
        txtCadComorb.setText(null);
        txtCadAFisicas.setText(null);
        txtCadQuais.setText(null);
        txtCadFreq.setText(null);
        txtCadDuracao.setText(null);
        txtCadPA.setText(null);
        txtCadFC.setText(null);
        txtCadFR.setText(null);
        txtCadInsp.setText(null);
        txtCadGonio.setText(null);
        txtCadTestEspec.setText(null);
        txtCadTestComp.setText(null);
        txtCadDor.setText(null);
        txtCadObj.setText(null);
        txtCadEmail.setText(null);
        txtCadPalp.setText(null);
        txtPesquisa.setText(null);
        ((DefaultTableModel) tblPacientes.getModel()).setRowCount(0);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane3 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        txtPesquisa = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        txtCadID = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        txtCadNome = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        txtCadIdade = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        txtCadData = new javax.swing.JFormattedTextField();
        jLabel47 = new javax.swing.JLabel();
        txtCadCPF = new javax.swing.JFormattedTextField();
        jLabel48 = new javax.swing.JLabel();
        txtCadSexo = new javax.swing.JTextField();
        jLabel49 = new javax.swing.JLabel();
        txtCadEstCivil = new javax.swing.JTextField();
        jLabel50 = new javax.swing.JLabel();
        txtCadProf = new javax.swing.JTextField();
        jLabel51 = new javax.swing.JLabel();
        txtCadEnd = new javax.swing.JTextField();
        jLabel52 = new javax.swing.JLabel();
        txtCadTel = new javax.swing.JFormattedTextField();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        txtCadPeso = new javax.swing.JTextField();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        txtCadAltura = new javax.swing.JTextField();
        jLabel57 = new javax.swing.JLabel();
        jScrollPane14 = new javax.swing.JScrollPane();
        txtCadDiagClin = new javax.swing.JTextArea();
        jLabel58 = new javax.swing.JLabel();
        jScrollPane15 = new javax.swing.JScrollPane();
        txtCadDiagFisio = new javax.swing.JTextArea();
        jLabel59 = new javax.swing.JLabel();
        jScrollPane16 = new javax.swing.JScrollPane();
        txtCadQPrinc = new javax.swing.JTextArea();
        jLabel60 = new javax.swing.JLabel();
        jScrollPane17 = new javax.swing.JScrollPane();
        txtCadHDA = new javax.swing.JTextArea();
        jLabel61 = new javax.swing.JLabel();
        jScrollPane18 = new javax.swing.JScrollPane();
        txtCadHDP = new javax.swing.JTextArea();
        jLabel62 = new javax.swing.JLabel();
        txtCadMedi = new javax.swing.JTextField();
        jLabel63 = new javax.swing.JLabel();
        txtCadComorb = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        txtCadAFisicas = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        txtCadQuais = new javax.swing.JTextField();
        Frequência1 = new javax.swing.JLabel();
        txtCadFreq = new javax.swing.JTextField();
        jLabel66 = new javax.swing.JLabel();
        txtCadDuracao = new javax.swing.JTextField();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        txtCadPA = new javax.swing.JTextField();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        txtCadFC = new javax.swing.JTextField();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        txtCadFR = new javax.swing.JTextField();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jScrollPane19 = new javax.swing.JScrollPane();
        txtCadInsp = new javax.swing.JTextArea();
        jLabel75 = new javax.swing.JLabel();
        jScrollPane20 = new javax.swing.JScrollPane();
        txtCadPalp = new javax.swing.JTextArea();
        jLabel76 = new javax.swing.JLabel();
        jScrollPane21 = new javax.swing.JScrollPane();
        txtCadGonio = new javax.swing.JTextArea();
        jLabel77 = new javax.swing.JLabel();
        jScrollPane22 = new javax.swing.JScrollPane();
        txtCadTestEspec = new javax.swing.JTextArea();
        jLabel78 = new javax.swing.JLabel();
        jScrollPane23 = new javax.swing.JScrollPane();
        txtCadTestComp = new javax.swing.JTextArea();
        jLabel79 = new javax.swing.JLabel();
        txtCadDor = new javax.swing.JTextField();
        jLabel80 = new javax.swing.JLabel();
        jScrollPane24 = new javax.swing.JScrollPane();
        txtCadObj = new javax.swing.JTextArea();
        btnCadCreate = new javax.swing.JButton();
        btnCadEdit = new javax.swing.JButton();
        btnCadDelete = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        txtCadEmail = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblPacientes = new javax.swing.JTable();
        txtCadCel = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(813, 600));
        setResizable(false);

        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane3.setPreferredSize(new java.awt.Dimension(790, 600));

        txtPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPesquisaKeyReleased(evt);
            }
        });

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/projetotcc/figuras/Search.png"))); // NOI18N

        jLabel42.setText("Campos Obrigatórios *");

        jLabel43.setText("ID");

        txtCadID.setEnabled(false);

        jLabel44.setText("*Nome");

        jLabel45.setText("Idade");

        jLabel46.setText("Data de Nascimento");

        try {
            txtCadData.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel47.setText("CPF");

        try {
            txtCadCPF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel48.setText("*Sexo");

        jLabel49.setText("Estado Civil");

        jLabel50.setText("Profissão");

        jLabel51.setText("Endereço");

        jLabel52.setText("Telefone Fixo");

        try {
            txtCadTel.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##) ####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel53.setText("*Celular");

        jLabel54.setText("Peso");

        jLabel55.setText("kg");

        jLabel56.setText("Altura");

        jLabel57.setText("Diagnóstico Clínico");

        txtCadDiagClin.setColumns(20);
        txtCadDiagClin.setLineWrap(true);
        txtCadDiagClin.setRows(5);
        jScrollPane14.setViewportView(txtCadDiagClin);

        jLabel58.setText("Diagnóstico Fisioterapêutico");

        txtCadDiagFisio.setColumns(20);
        txtCadDiagFisio.setLineWrap(true);
        txtCadDiagFisio.setRows(5);
        jScrollPane15.setViewportView(txtCadDiagFisio);

        jLabel59.setText("QueixaPrincipal");

        txtCadQPrinc.setColumns(20);
        txtCadQPrinc.setLineWrap(true);
        txtCadQPrinc.setRows(5);
        jScrollPane16.setViewportView(txtCadQPrinc);

        jLabel60.setText("HDA");

        txtCadHDA.setColumns(20);
        txtCadHDA.setLineWrap(true);
        txtCadHDA.setRows(5);
        jScrollPane17.setViewportView(txtCadHDA);

        jLabel61.setText("HDP");

        txtCadHDP.setColumns(20);
        txtCadHDP.setRows(5);
        jScrollPane18.setViewportView(txtCadHDP);

        jLabel62.setText("Medicamentos");

        txtCadMedi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCadMediActionPerformed(evt);
            }
        });

        jLabel63.setText("Comorbidades");

        jLabel64.setText("Pratica Atividades Físicas?");

        jLabel65.setText("Se sim, Quais Atividades?");

        Frequência1.setText("Frequência");

        jLabel66.setText("Duração");

        jLabel67.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel67.setText("Dados Pessoais");

        jLabel68.setText("PA");

        jLabel69.setText("bpm");

        jLabel70.setText("FC");

        jLabel71.setText("mmhg");

        jLabel72.setText("FR");

        jLabel73.setText("rpm");

        jLabel74.setText("Inspeção");

        txtCadInsp.setColumns(20);
        txtCadInsp.setLineWrap(true);
        txtCadInsp.setRows(5);
        jScrollPane19.setViewportView(txtCadInsp);

        jLabel75.setText("Palpação");

        txtCadPalp.setColumns(20);
        txtCadPalp.setLineWrap(true);
        txtCadPalp.setRows(5);
        jScrollPane20.setViewportView(txtCadPalp);

        jLabel76.setText("Goniometria");

        txtCadGonio.setColumns(20);
        txtCadGonio.setLineWrap(true);
        txtCadGonio.setRows(5);
        jScrollPane21.setViewportView(txtCadGonio);

        jLabel77.setText("Testes Específicos");

        txtCadTestEspec.setColumns(20);
        txtCadTestEspec.setLineWrap(true);
        txtCadTestEspec.setRows(5);
        jScrollPane22.setViewportView(txtCadTestEspec);

        jLabel78.setText("Testes Complementares");

        txtCadTestComp.setColumns(20);
        txtCadTestComp.setLineWrap(true);
        txtCadTestComp.setRows(5);
        jScrollPane23.setViewportView(txtCadTestComp);

        jLabel79.setText("Nível de Dor");

        jLabel80.setText("Objetivos");

        txtCadObj.setColumns(20);
        txtCadObj.setRows(5);
        jScrollPane24.setViewportView(txtCadObj);

        btnCadCreate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/projetotcc/figuras/Create.png"))); // NOI18N
        btnCadCreate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCadCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadCreateActionPerformed(evt);
            }
        });

        btnCadEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/projetotcc/figuras/Update.png"))); // NOI18N
        btnCadEdit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCadEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadEditActionPerformed(evt);
            }
        });

        btnCadDelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/projetotcc/figuras/Delete.png"))); // NOI18N
        btnCadDelete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCadDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadDeleteActionPerformed(evt);
            }
        });

        jLabel1.setText("E-mail");

        tblPacientes = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        tblPacientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Idade", "DtNasc", "CPF", "Sexo", "EstadoCivil", "Profissao", "Endereco", "Telefone", "Celular", "Email", "Peso", "Altura", "DiagnósticoClínico", "DiagnósticoFisioterapêutico", "QueixaPrincipal", "HDA", "HDP", "Medicamentos", "Comorbidades", "AtividadesFísicas", "QuaisAtividades", "Frequência", "Duração", "PA", "FC", "FR", "Inspeção", "Palpação", "Goniometria", "TestesEspecíficos", "TestesComplementares", "Dor", "Objetivos"
            }
        ));
        tblPacientes.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tblPacientes.setFocusable(false);
        tblPacientes.setShowGrid(true);
        tblPacientes.getTableHeader().setReorderingAllowed(false);
        tblPacientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPacientesMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblPacientes);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 767, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(txtCadEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(104, 104, 104)
                                .addComponent(btnCadCreate)
                                .addGap(119, 119, 119)
                                .addComponent(btnCadEdit)
                                .addGap(128, 128, 128)
                                .addComponent(btnCadDelete)))
                        .addGap(0, 30, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel67)
                        .addGap(346, 346, 346))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(txtCadCel, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(14, 14, 14)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel43)
                                        .addComponent(jLabel44))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtCadID, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtCadNome)))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel62)
                                            .addGap(18, 18, 18)
                                            .addComponent(txtCadMedi))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel63)
                                            .addGap(18, 18, 18)
                                            .addComponent(txtCadComorb))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel64)
                                            .addGap(18, 18, 18)
                                            .addComponent(txtCadAFisicas, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(jLabel65)
                                            .addGap(18, 18, 18)
                                            .addComponent(txtCadQuais))
                                        .addComponent(jScrollPane24)
                                        .addComponent(jScrollPane23)
                                        .addComponent(jScrollPane22)
                                        .addComponent(jScrollPane21)
                                        .addComponent(jScrollPane20)
                                        .addComponent(jScrollPane19)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                            .addComponent(jLabel51)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(txtCadEnd))
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                            .addComponent(jLabel49)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(txtCadEstCivil, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(jLabel50)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(txtCadProf, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                    .addGap(18, 18, 18)
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                            .addComponent(jLabel52)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(txtCadTel, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(jLabel53))
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                            .addComponent(jLabel54)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(txtCadPeso, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                            .addComponent(jLabel55)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(jLabel56)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(txtCadAltura, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                .addComponent(jLabel57)
                                                .addComponent(jLabel58)
                                                .addComponent(jLabel59)
                                                .addComponent(jLabel60)
                                                .addComponent(jLabel61)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel72)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(txtCadFR, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jLabel73)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jLabel79)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(txtCadDor, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addComponent(jLabel74)
                                                .addComponent(jLabel75)
                                                .addComponent(jLabel76)
                                                .addComponent(jLabel77)
                                                .addComponent(jLabel78)
                                                .addComponent(jLabel80)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(Frequência1)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(txtCadFreq, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jLabel66)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(txtCadDuracao, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jLabel68)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(txtCadPA, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jLabel71)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jLabel70)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(txtCadFC, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jLabel69)))
                                            .addGap(6, 6, 6)))
                                    .addGap(0, 56, Short.MAX_VALUE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel45)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtCadIdade, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel46)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtCadData, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel47)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtCadCPF, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel48)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtCadSexo)))
                            .addGap(5, 5, 5))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addGap(21, 21, 21)
                            .addComponent(txtPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel41)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel42)
                            .addGap(32, 32, 32))
                        .addComponent(jScrollPane15, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane16, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane17, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane18, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane14))
                    .addContainerGap()))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel67)
                .addGap(158, 158, 158)
                .addComponent(txtCadCel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(txtCadEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1749, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCadCreate)
                    .addComponent(btnCadEdit)
                    .addComponent(btnCadDelete))
                .addGap(113, 113, 113))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(txtPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel41)
                        .addComponent(jLabel42))
                    .addGap(216, 216, 216)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel43)
                        .addComponent(txtCadID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel44)
                        .addComponent(txtCadNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel45)
                        .addComponent(txtCadIdade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel46)
                        .addComponent(txtCadData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel47)
                        .addComponent(txtCadCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel48)
                        .addComponent(txtCadSexo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel49)
                        .addComponent(txtCadEstCivil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel50)
                        .addComponent(txtCadProf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel52)
                        .addComponent(txtCadTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel53))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel51)
                        .addComponent(txtCadEnd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel54)
                        .addComponent(txtCadPeso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel55)
                        .addComponent(jLabel56)
                        .addComponent(txtCadAltura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(90, 90, 90)
                    .addComponent(jLabel57)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel58)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel59)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel60)
                    .addGap(18, 18, 18)
                    .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel61)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel62)
                        .addComponent(txtCadMedi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel63)
                        .addComponent(txtCadComorb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel64)
                        .addComponent(txtCadAFisicas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel65)
                        .addComponent(txtCadQuais, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Frequência1)
                        .addComponent(txtCadFreq, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel66)
                        .addComponent(txtCadDuracao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel68)
                        .addComponent(txtCadPA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel69)
                        .addComponent(jLabel70)
                        .addComponent(txtCadFC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel71))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel72)
                        .addComponent(txtCadFR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel73)
                        .addComponent(jLabel79)
                        .addComponent(txtCadDor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addComponent(jLabel74)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel75)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel76)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel77)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel78)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel80)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(265, Short.MAX_VALUE)))
        );

        jScrollPane3.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 841, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 2425, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(857, 2433));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtCadMediActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCadMediActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCadMediActionPerformed

    private void btnCadCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadCreateActionPerformed
        // TODO add your handling code here:
        criar();
    }//GEN-LAST:event_btnCadCreateActionPerformed

    private void txtPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPesquisaKeyReleased
        // TODO add your handling code here:
        pesquisa();
    }//GEN-LAST:event_txtPesquisaKeyReleased

    private void tblPacientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPacientesMouseClicked
        // TODO add your handling code here:
        setcampos();
    }//GEN-LAST:event_tblPacientesMouseClicked

    private void btnCadEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadEditActionPerformed
        // TODO add your handling code here:
        editar();
    }//GEN-LAST:event_btnCadEditActionPerformed

    private void btnCadDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadDeleteActionPerformed
        // TODO add your handling code here:
        deletar();
    }//GEN-LAST:event_btnCadDeleteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadPacientesScroll.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadPacientesScroll.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadPacientesScroll.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadPacientesScroll.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadPacientesScroll().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Frequência1;
    private javax.swing.JButton btnCadCreate;
    private javax.swing.JButton btnCadDelete;
    private javax.swing.JButton btnCadEdit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane24;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JTable tblPacientes;
    private javax.swing.JTextField txtCadAFisicas;
    private javax.swing.JTextField txtCadAltura;
    private javax.swing.JFormattedTextField txtCadCPF;
    private javax.swing.JTextField txtCadCel;
    private javax.swing.JTextField txtCadComorb;
    private javax.swing.JFormattedTextField txtCadData;
    private javax.swing.JTextArea txtCadDiagClin;
    private javax.swing.JTextArea txtCadDiagFisio;
    private javax.swing.JTextField txtCadDor;
    private javax.swing.JTextField txtCadDuracao;
    private javax.swing.JTextField txtCadEmail;
    private javax.swing.JTextField txtCadEnd;
    private javax.swing.JTextField txtCadEstCivil;
    private javax.swing.JTextField txtCadFC;
    private javax.swing.JTextField txtCadFR;
    private javax.swing.JTextField txtCadFreq;
    private javax.swing.JTextArea txtCadGonio;
    private javax.swing.JTextArea txtCadHDA;
    private javax.swing.JTextArea txtCadHDP;
    private javax.swing.JTextField txtCadID;
    private javax.swing.JTextField txtCadIdade;
    private javax.swing.JTextArea txtCadInsp;
    private javax.swing.JTextField txtCadMedi;
    private javax.swing.JTextField txtCadNome;
    private javax.swing.JTextArea txtCadObj;
    private javax.swing.JTextField txtCadPA;
    private javax.swing.JTextArea txtCadPalp;
    private javax.swing.JTextField txtCadPeso;
    private javax.swing.JTextField txtCadProf;
    private javax.swing.JTextArea txtCadQPrinc;
    private javax.swing.JTextField txtCadQuais;
    private javax.swing.JTextField txtCadSexo;
    private javax.swing.JFormattedTextField txtCadTel;
    private javax.swing.JTextArea txtCadTestComp;
    private javax.swing.JTextArea txtCadTestEspec;
    private javax.swing.JTextField txtPesquisa;
    // End of variables declaration//GEN-END:variables
}
